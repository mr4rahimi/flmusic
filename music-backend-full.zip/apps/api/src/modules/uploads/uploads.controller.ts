import {
  Controller,
  Post,
  Body,
  UseGuards,
  Request,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';
import { IsUrl, IsString, IsOptional, IsArray } from 'class-validator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { UrlUploadService } from './url-upload.service';

export class UploadFromUrlDto {
  @ApiProperty({ example: 'https://example.com/song.mp3' })
  @IsUrl()
  url: string;

  @ApiProperty({ example: 'عنوان آهنگ' })
  @IsString()
  title: string;

  @ApiPropertyOptional({ example: 'pop' })
  @IsOptional()
  @IsString()
  genre?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsArray()
  tags?: string[];

  @ApiPropertyOptional({ enum: ['public', 'private'] })
  @IsOptional()
  @IsString()
  visibility?: string;
}

@ApiTags('Uploads')
@Controller('uploads')
export class UploadsController {
  constructor(private readonly urlUploadService: UrlUploadService) {}

  @Post('from-url')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Upload track from URL' })
  uploadFromUrl(@Body() dto: UploadFromUrlDto, @Request() req: any) {
    return this.urlUploadService.uploadFromUrl(dto, req.user.id);
  }
}
