import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BullModule } from '@nestjs/bull';
import { Track } from '../tracks/track.entity';
import { UploadProcessor } from './upload.processor';
import { UploadsController } from './uploads.controller';
import { UrlUploadService } from './url-upload.service';
import { SearchModule } from '../search/search.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Track]),
    BullModule.registerQueue({ name: 'audio' }),
    SearchModule,
  ],
  controllers: [UploadsController],
  providers: [UploadProcessor, UrlUploadService],
})
export class UploadsModule {}
