import {
  Injectable,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { InjectQueue } from '@nestjs/bull';
import type { Queue } from 'bull';
import { Track, TrackVisibility } from '../tracks/track.entity';
import { UPLOAD_DIR } from '../../config/upload.config';
import { join } from 'path';
import { createWriteStream, existsSync, mkdirSync } from 'fs';

// eslint-disable-next-line @typescript-eslint/no-require-imports
const { v4: uuidv4 } = require('uuid');

@Injectable()
export class UrlUploadService {
  private readonly logger = new Logger(UrlUploadService.name);

  constructor(
    @InjectRepository(Track)
    private readonly trackRepo: Repository<Track>,
    @InjectQueue('audio')
    private readonly audioQueue: Queue,
  ) {}

  async uploadFromUrl(dto: any, userId: string): Promise<Track> {
    const { url, title, genre, description, tags, visibility } = dto;

    const allowedExtensions = ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a'];
    const urlLower = url.toLowerCase().split('?')[0];
    const hasAudioExt = allowedExtensions.some((ext) => urlLower.endsWith(ext));

    if (!hasAudioExt) {
      throw new BadRequestException(
        'URL باید به یک فایل صوتی اشاره کند (mp3, wav, flac, ...)',
      );
    }

    const originalDir = join(UPLOAD_DIR, 'original');
    if (!existsSync(originalDir)) mkdirSync(originalDir, { recursive: true });

    const ext = urlLower.split('.').pop() || 'mp3';
    const filename = `${uuidv4()}.${ext}`;
    const filePath = join(originalDir, filename);

    this.logger.log(`Downloading from URL: ${url}`);
    await this.downloadFile(url, filePath);
    this.logger.log(`Downloaded successfully: ${filename}`);

    const track = this.trackRepo.create({
      userId,
      title,
      description,
      genre,
      tags,
      visibility: (visibility as TrackVisibility) || TrackVisibility.PUBLIC,
      originalAudioUrl: filePath,
    });

    const saved = await this.trackRepo.save(track);

    await this.audioQueue.add('process-audio', {
      trackId: saved.id,
      filePath,
    });

    return saved;
  }

  private async downloadFile(url: string, filePath: string): Promise<void> {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const https = require('https');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const http = require('http');

    await new Promise<void>((resolve, reject) => {
      const protocol = url.startsWith('https') ? https : http;
      const options = {
        rejectUnauthorized: false,
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; MusicBot/1.0)',
        },
      };

      const makeRequest = (reqUrl: string) => {
        protocol.get(reqUrl, options, (response: any) => {
          if (response.statusCode === 301 || response.statusCode === 302) {
            const redirectUrl = response.headers.location;
            if (redirectUrl) {
              makeRequest(redirectUrl);
              return;
            }
          }

          if (response.statusCode !== 200) {
            reject(new BadRequestException(`سرور پاسخ ${response.statusCode} داد`));
            return;
          }

          const contentLength = parseInt(response.headers['content-length'] || '0');
          if (contentLength > 100 * 1024 * 1024) {
            reject(new BadRequestException('فایل بیش از ۱۰۰MB است'));
            return;
          }

          const writer = createWriteStream(filePath);
          response.pipe(writer);
          writer.on('finish', resolve);
          writer.on('error', reject);
        }).on('error', (err: Error) => {
          reject(new BadRequestException(`خطا در دانلود: ${err.message}`));
        }).setTimeout(60000, function() {
          this.destroy();
          reject(new BadRequestException('timeout: سرور پاسخ نداد'));
        });
      };

      makeRequest(url);
    });
  }
}
