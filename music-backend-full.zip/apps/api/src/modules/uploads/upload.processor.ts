import { Processor, Process } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import type { Job } from 'bull';
import { join } from 'path';
import { existsSync, mkdirSync } from 'fs';
import Ffmpeg from 'fluent-ffmpeg';
import { Track, TrackStatus } from '../tracks/track.entity';
import { UPLOAD_DIR } from '../../config/upload.config';
import { SearchService } from '../search/search.service';

export interface AudioJobData {
  trackId: string;
  filePath: string;
}

@Processor('audio')
export class UploadProcessor {
  private readonly logger = new Logger(UploadProcessor.name);

  constructor(
    @InjectRepository(Track)
    private readonly trackRepo: Repository<Track>,
    private readonly searchService: SearchService,
  ) {}

  @Process('process-audio')
  async handleAudioProcessing(job: Job<AudioJobData>) {
    const { trackId, filePath } = job.data;
    this.logger.log(`Processing track ${trackId}`);

    try {
      const processedDir = join(UPLOAD_DIR, 'processed');
      if (!existsSync(processedDir)) mkdirSync(processedDir, { recursive: true });

      const outputFileName = `${trackId}.mp3`;
      const outputPath = join(processedDir, outputFileName);

      const duration = await this.processAudio(filePath, outputPath);
      const waveformData = this.generateMockWaveform();

      await this.trackRepo.update(trackId, {
        audioUrl: `uploads/processed/${outputFileName}`,
        duration,
        waveformData,
        status: TrackStatus.READY,
      });

      // index توی meilisearch
      const track = await this.trackRepo.findOne({
        where: { id: trackId },
        relations: { user: true },
      });
      if (track) await this.searchService.indexTrack(track);

      this.logger.log(`Track ${trackId} processed and indexed`);
    } catch (error) {
      this.logger.error(`Failed to process track ${trackId}`, error);
      await this.trackRepo.update(trackId, { status: TrackStatus.FAILED });
    }
  }

  private processAudio(inputPath: string, outputPath: string): Promise<number> {
    return new Promise((resolve, reject) => {
      let duration = 0;

      Ffmpeg(inputPath)
        .audioCodec('libmp3lame')
        .audioBitrate(192)
        .audioFilters('loudnorm')
        .on('codecData', (data: any) => {
          const parts = data.duration.split(':');
          duration = +parts[0] * 3600 + +parts[1] * 60 + parseFloat(parts[2]);
        })
        .on('end', () => resolve(Math.round(duration)))
        .on('error', reject)
        .save(outputPath);
    });
  }

  private generateMockWaveform(): number[] {
    return Array.from({ length: 100 }, () => Math.round(Math.random() * 100));
  }
}
